<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsangController extends Controller
{
    //ditambahkan ini sedikit
    public function index(){
        echo "ini dari index punya usang controller";
    }

    public function godog(){
        echo "iki tulisan e putih";
    }
}
